#!/bin/bash
#The power tests (22 queries)
#Parameters description:
#VALIDATION - Generate queries with random substitution parameters, when $1=1 and with validation values when $1=0.
#SF - scale factor.
#ORDERS_LINETEM_DIR - name of directory where data for generate refresh function be found.
#INDEX - index for generating refresh functions.
#SCHEMA_NAME - name of tpch schema.
#HANA_USERNAME - hana user name.
#HANA_PASSWORD - hana password.

VALIDATION=$1
SF=$2
ORDERS_LINETEM_DIR=$3
INDEX=$4
SCHEMA_NAME=$5
HANA_USERNAME=$6
HANA_PASSWORD=$7

echo Prepare queries
sh ./prepare_queries.sh $VALIDATION $SF

echo Prepare refresh functions.
sh ./refresh_gen.sh $ORDERS_LINETEM_DIR $INDEX $SCHEMA_NAME $HANA_USERNAME $HANA_PASSWORD

#prepare refresh tests for executing in refresh stream.
cat > rf1_tmp.sh <<DELIM
START=\$(date +%s%N)
hdbsql -u $HANA_USERNAME -p $HANA_PASSWORD -i 00 -x -j -a -o outputrf1_$INDEX -I rf1_$INDEX.sql
END=\$(date +%s%N)
echo rf1 completed in \$(((\$END-\$START)/1000000)) ms
echo "rf1;\$(((\$END-\$START)/1000000))" > power_test.log
DELIM

cat > rf2_tmp.sh <<DELIM
START=\$(date +%s%N)
hdbsql -u $HANA_USERNAME -p $HANA_PASSWORD -i 00 -x -j -a -o outputrf2_$INDEX -I rf2_$INDEX.sql
END=\$(date +%s%N)
echo rf2 completed in \$(((\$END-\$START)/1000000)) ms
echo "rf2;\$(((\$END-\$START)/1000000))" >> power_test.log
DELIM

#prepare query stream
QUERY_SEQ=(14 2 9 20 6 17 18 8 21 13 3 22 16 4 11 15 1 10 19 5 7 12)
for QUERY_N in ${QUERY_SEQ[@]};
do
	cat >> query_tmp.sh <<DELIM
START=\$(date +%s%N)
hdbsql -u $HANA_USERNAME -p $HANA_PASSWORD -i 00 -x -j -a -o outputq$QUERY_N -I q$QUERY_N.sql
END=\$(date +%s%N)
echo q$QUERY_N completed in \$(((\$END-\$START)/1000000)) ms
echo "q$QUERY_N;\$(((\$END-\$START)/1000000))" >> power_test.log

DELIM
done

ALL_START=$(date +%s%N)
#start refresh stream with rf1.
sh ./rf1_tmp.sh &
RF1_PID=$!
wait $RF1_PID

#start query stream.
sh ./query_tmp.sh rf1_tmp &
QUERY_PID=$!
wait $QUERY_PID

#start refresh stream with rf2.
sh ./rf2_tmp.sh query_tmp &
RF2_PID=$!
wait $RF2_PID
ALL_END=$(date +%s%N)
echo The power test completed in $((($ALL_END-$ALL_START)/1000000)) ms

#drop temp files.
rm rf1_tmp.sh
rm query_tmp.sh
rm rf2_tmp.sh



