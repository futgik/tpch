#!/bin/bash
#Generate query 9 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
COLORS=("almond" "antique" "aquamarine" "azure" "beige" "bisque" "black" "blanched" "blue" "blush" "brown" "burlywood" "burnished" "chartreuse" "chiffon" "chocolate" "coral" "cornflower" "cornsilk" "cream" "cyan" "dark" "deep" "dim" "dodger" "drab" "firebrick" "floral" "forest" "frosted" "gainsboro" "ghost" "goldenrod" "green" "grey" "honeydew" "hot" "indian" "ivory" "khaki" "lace" "lavender" "lawn" "lemon" "light" "lime" "linen" "magenta" "maroon" "medium" "metallic" "midnight" "mint" "misty" "moccasin" "navajo" "navy" "olive" "orange" "orchid" "pale" "papaya" "peach" "peru" "pink" "plum" "powder" "puff" "purple" "red" "rose" "rosy" "royal" "saddle" "salmon" "sandy" "seashell" "sienna" "sky" "slate" "smoke" "snow" "spring" "steel" "tan" "thistle" "tomato" "turquoise" "violet" "wheat" "white" "yellow")
COLOR=$([[ $VAL == 1 ]]  && echo green || echo ${COLORS[$(($(shuf -i 1-${#COLORS[@]} -n 1)-1))]})
cat > q9.sql <<DELIM
-- Product Type Profit Measure Query (Q9)

SELECT nation, 
       o_year, 
       Sum(amount) AS sum_profit 
FROM   (SELECT n_name 
               AS 
                      nation, 
               Extract(year FROM o_orderdate) 
               AS 
                      o_year, 
               l_extendedprice * ( 1 - l_discount ) - ps_supplycost * l_quantity 
               AS 
                      amount 
        FROM   part, 
               supplier, 
               lineitem, 
               partsupp, 
               orders, 
               nation 
        WHERE  s_suppkey = l_suppkey 
               AND ps_suppkey = l_suppkey 
               AND ps_partkey = l_partkey 
               AND p_partkey = l_partkey 
               AND o_orderkey = l_orderkey 
               AND s_nationkey = n_nationkey 
               AND p_name LIKE '%$COLOR%') AS profit 
GROUP  BY nation, 
          o_year 
ORDER  BY nation, 
          o_year DESC
WITH HINT (OLAP_PARALLEL_AGGREGATION);
DELIM