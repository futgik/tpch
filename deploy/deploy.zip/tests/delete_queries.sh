#!/bin/bash
#remove files after prepare_queries
rm q1.sql
rm q2.sql
rm q3.sql
rm q4.sql
rm q5.sql
rm q6.sql
rm q7.sql
rm q8.sql
rm q9.sql
rm q10.sql
rm q11.sql
rm q12.sql
rm q13.sql
rm q14.sql
rm q15.sql
rm q16.sql
rm q17.sql
rm q18.sql
rm q19.sql
rm q20.sql
rm q21.sql
rm q22.sql