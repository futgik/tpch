#!/bin/bash
#Generate query 6 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
DATE=$([[ $VAL == 1 ]]  && echo 1994 || echo $(shuf -i 1993-1997 -n 1))
DISCOUNT=$([[ $VAL == 1 ]]  && echo 6 || echo $(shuf -i 2-9 -n 1))
QUANTITY=$([[ $VAL == 1 ]]  && echo 24 || echo $(shuf -i 24-25 -n 1))
cat > q6.sql <<DELIM
-- Forecasting Revenue Change Query (Q6)

SELECT sum(l_extendedprice * l_discount) AS revenue
FROM lineitem
WHERE l_shipdate >= DATE '$DATE-01-01'
	AND l_shipdate < ADD_DAYS(TO_DATE('$DATE-01-01', 'YYYY-MM-DD'), + 360)
	AND l_discount BETWEEN 0.0$DISCOUNT - 0.01
		AND 0.0$DISCOUNT + 0.01
	AND l_quantity < $QUANTITY;
DELIM