#!/bin/bash
#Generate query 10 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
YEAR=$([[ $VAL == 1 ]]  && echo 1993 || echo $(shuf -i 1993-1994 -n 1))
MONTH_MIN=$([[ $YEAR == 1993 ]] && echo 2 || echo 1)
MONTH=$([[ $VAL == 1 ]]  && echo 10 || (printf -v j "%02d" $(shuf -i $MONTH_MIN-12 -n 1) && echo $j))
cat > q10.sql <<DELIM
-- Returned Item Reporting Query (Q10)

SELECT c_custkey
	,c_name
	,sum(l_extendedprice * (1 - l_discount)) AS revenue
	,c_acctbal
	,n_name
	,c_address
	,c_phone
	,c_comment
FROM customer
	,orders
	,lineitem
	,nation
WHERE c_custkey = o_custkey
	AND l_orderkey = o_orderkey
	AND o_orderdate >= DATE '$YEAR-$MONTH-01'
	AND o_orderdate < ADD_DAYS(TO_DATE('$YEAR-$MONTH-01', 'YYYY-MM-DD'), + 90)
	AND l_returnflag = 'R'
	AND c_nationkey = n_nationkey
GROUP BY c_custkey
	,c_name
	,c_acctbal
	,c_phone
	,n_name
	,c_address
	,c_comment
ORDER BY revenue DESC;
DELIM
