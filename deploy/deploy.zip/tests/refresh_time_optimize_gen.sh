#!/bin/bash
# generate both refresh function 1 and refresh function 2 sql scripts

ORDERS_LINETEM_DIR=$1
INDEX=$2
SCHEMA_NAME=$3
HANA_USERNAME=$4
HANA_PASSWORD=$5

set -e

sh ./rf1.sh $ORDERS_LINETEM_DIR $INDEX
sh ./rf2_time_optimize_sql_gen.sh $ORDERS_LINETEM_DIR $INDEX $SCHEMA_NAME $HANA_USERNAME $HANA_PASSWORD