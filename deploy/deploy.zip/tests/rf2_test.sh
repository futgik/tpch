#!/bin/bash
#run rf2 test, measure time of execution and write result to file OUTPUT_FILE
#Parameters description:
#OUTPUT_FILE - output file with results.
#INDEX - index for generating refresh functions.
#HANA_USERNAME - hana user name.
#HANA_PASSWORD - hana password.
OUTPUT_FILE=$1
INDEX=$2
HANA_USERNAME=$3
HANA_PASSWORD=$4

START=$(date +%s%N)
hdbsql -u $HANA_USERNAME -p $HANA_PASSWORD -i 00 -x -j -a -o outputrf21_$INDEX -I rf21_$INDEX.sql
pid1=$!
hdbsql -u $HANA_USERNAME -p $HANA_PASSWORD -i 00 -x -j -a -o outputrf22_$INDEX -I rf22_$INDEX.sql
pid2=$!
wait $pid1
wait $pid2
END=$(date +%s%N)
echo rf2 completed in $((($END-$START)/1000000)) ms
echo "rf2;$((($END-$START)/1000000))" >> $OUTPUT_FILE