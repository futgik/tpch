#!/bin/bash
#Generate query 2 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
TYPES=("TIN" "NICKEL" "BRASS" "STEEL" "COPPER")
REGIONS=("AFRICA" "AMERICA" "ASIA" "EUROPE" "MIDDLE EAST")
SIZE=$([[ $VAL == 1 ]]  && echo 15 || echo $(shuf -i 1-50 -n 1))
TYPE=$([[ $VAL == 1 ]]  && echo BRASS || echo ${TYPES[$(($(shuf -i 1-${#TYPES[@]} -n 1)-1))]})
REGION=$([[ $VAL == 1 ]]  && echo EUROPE || echo ${REGIONS[$(($(shuf -i 1-${#REGIONS[@]} -n 1)-1))]})
cat > q2.sql <<DELIM
-- Minimum Cost Supplier Query (Q2)

SELECT s_acctbal, 
       s_name, 
       n_name, 
       p_partkey, 
       p_mfgr, 
       s_address, 
       s_phone, 
       s_comment 
FROM   part, 
       supplier, 
       partsupp, 
       nation, 
       region 
WHERE  p_partkey = ps_partkey 
       AND s_suppkey = ps_suppkey 
       AND p_size = '$SIZE' 
       AND p_type LIKE '%$TYPE' 
       AND s_nationkey = n_nationkey 
       AND n_regionkey = r_regionkey 
       AND r_name = '$REGION' 
       AND ps_supplycost = (SELECT Min(ps_supplycost) 
                            FROM   partsupp, 
                                   supplier, 
                                   nation, 
                                   region 
                            WHERE  p_partkey = ps_partkey 
                                   AND s_suppkey = ps_suppkey 
                                   AND s_nationkey = n_nationkey 
                                   AND n_regionkey = r_regionkey 
                                   AND r_name = '$REGION') 
ORDER  BY s_acctbal DESC, 
          n_name, 
          s_name, 
          p_partkey;   
DELIM