#!/bin/bash
#Generate query 22 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1

function rm_from_list {	
	VALUE=$1
	RESULT=()
	for S in ${IL[@]}; do if [ $S != $VALUE ]; then RESULT+=($S); fi; done
	echo "${RESULT[@]}" > /tmp/rm_from_list
}

IL=()
for i in {10..34}; do IL+=($i); done
I1=$([[ $VAL == 1 ]]  && echo 13 || echo ${IL[$(($(shuf -i 1-${#IL[@]} -n 1)-1))]})
$(rm_from_list $I1)
read -r -a IL < /tmp/rm_from_list
I2=$([[ $VAL == 1 ]]  && echo 31 || echo ${IL[$(($(shuf -i 1-${#IL[@]} -n 1)-1))]})
$(rm_from_list $I2)
read -r -a IL < /tmp/rm_from_list
I3=$([[ $VAL == 1 ]]  && echo 23 || echo ${IL[$(($(shuf -i 1-${#IL[@]} -n 1)-1))]})
$(rm_from_list $I3)
read -r -a IL < /tmp/rm_from_list
I4=$([[ $VAL == 1 ]]  && echo 29 || echo ${IL[$(($(shuf -i 1-${#IL[@]} -n 1)-1))]})
$(rm_from_list $I4)
read -r -a IL < /tmp/rm_from_list
I5=$([[ $VAL == 1 ]]  && echo 30 || echo ${IL[$(($(shuf -i 1-${#IL[@]} -n 1)-1))]})
$(rm_from_list $I5)
read -r -a IL < /tmp/rm_from_list
I6=$([[ $VAL == 1 ]]  && echo 18 || echo ${IL[$(($(shuf -i 1-${#IL[@]} -n 1)-1))]})
$(rm_from_list $I6)
read -r -a IL < /tmp/rm_from_list
I7=$([[ $VAL == 1 ]]  && echo 17 || echo ${IL[$(($(shuf -i 1-${#IL[@]} -n 1)-1))]})
cat > q22.sql <<DELIM
 -- Global Sales Opportunity Query (Q22)
set schema tpch;
 SELECT top 1000
	 cntrycode
	,count(*) AS numcust
	,sum(c_acctbal) AS totacctbal
FROM (
	SELECT substring(c_phone, 1) AS cntrycode
		,c_acctbal
	FROM customer
	WHERE substring(c_phone, 1, 2) IN (
			'$I1'
			,'$I2'
			,'$I3'
			,'$I4'
			,'$I5'
			,'$I6'
			,'$I7'
			)
		AND c_acctbal > (
			SELECT avg(c_acctbal)
			FROM customer
			WHERE c_acctbal > 0.00
				AND substring(c_phone, 1, 2) IN (
					'$I1'
					,'$I2'
					,'$I3'
					,'$I4'
					,'$I5'
					,'$I6'
					,'$I7'
					)
			)
		AND NOT EXISTS (
			SELECT *
			FROM orders
			WHERE o_custkey = c_custkey
			)
	) AS custsale
GROUP BY cntrycode
ORDER BY cntrycode;
DELIM