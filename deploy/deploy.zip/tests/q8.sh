#!/bin/bash
#Generate query 8 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1

REGIONS=("AFRICA" "AMERICA" "ASIA" "EUROPE" "MIDDLE EAST")
REGION=$([[ $VAL == 1 ]]  && echo AMERICA || echo ${REGIONS[$(($(shuf -i 1-${#REGIONS[@]} -n 1)-1))]})
NATIONS=()
if [ $REGION == "AFRICA" ]; 
then 
	NATIONS=("ALGERIA" "ETHIOPIA" "MOROCCO" "KENYA" "MOZAMBIQUE")		
elif [ $REGION == "AMERICA" ];
then
	NATIONS=("ARGENTINA" "BRAZIL" "CANADA" "PERU" "UNITED STATES")
elif [ $REGION == "ASIA" ];
then
	NATIONS=("INDIA" "INDONESIA" "JAPAN" "CHINA" "VIETNAM")
elif [ $REGION == "EUROPE" ];
then
	NATIONS=("FRANCE" "GERMANY" "ROMANIA" "RUSSIA" "UNITED KINGDOM")
else 
	NATIONS=("EGYPT" "IRAN" "IRAQ" "JORDAN" "SAUDI ARABIA")
fi
NATION=$([[ $VAL == 1 ]]  && echo BRAZIL || echo ${NATIONS[$(($(shuf -i 1-${#NATIONS[@]} -n 1)-1))]})

SYLLABLE1=("STANDARD" "SMALL" "MEDIUM" "LARGE" "ECONOMY" "PROMO")
TYPE1=$([[ $VAL == 1 ]]  && echo ECONOMY || echo ${SYLLABLE1[$(($(shuf -i 1-${#SYLLABLE1[@]} -n 1)-1))]})
SYLLABLE2=("ANODIZED" "BURNISHED" "PLATED" "POLISHED" "BRUSHED")
TYPE2=$([[ $VAL == 1 ]]  && echo ANODIZED || echo ${SYLLABLE2[$(($(shuf -i 1-${#SYLLABLE2[@]} -n 1)-1))]})
SYLLABLE3=("TIN" "NICKEL" "BRASS" "STEEL" "COPPER")
TYPE3=$([[ $VAL == 1 ]]  && echo STEEL || echo ${SYLLABLE3[$(($(shuf -i 1-${#SYLLABLE3[@]} -n 1)-1))]})

cat > q8.sql <<DELIM
-- National Market Share Query (Q8)

SELECT o_year
	,sum(CASE 
			WHEN nation = '$NATION'
				THEN volume
			ELSE 0
			END) / sum(volume) AS mkt_share
FROM (
	SELECT extract(year FROM o_orderdate) AS o_year
		,l_extendedprice * (1 - l_discount) AS volume
		,n2.n_name AS nation
	FROM part
		,supplier
		,lineitem
		,orders
		,customer
		,nation n1
		,nation n2
		,region
	WHERE p_partkey = l_partkey
		AND s_suppkey = l_suppkey
		AND l_orderkey = o_orderkey
		AND o_custkey = c_custkey
		AND c_nationkey = n1.n_nationkey
		AND n1.n_regionkey = r_regionkey
		AND r_name = '$REGION'
		AND s_nationkey = n2.n_nationkey
		AND o_orderdate BETWEEN DATE '1995-01-01'
			AND DATE '1996-12-31'
		AND p_type = '$TYPE1 $TYPE2 $TYPE3'
	) AS all_nations
GROUP BY o_year
ORDER BY o_year;
DELIM
