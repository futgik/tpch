#!/bin/bash
#Generate query 13 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
WORDS1=("special" "pending" "unusual" "express")
WORD1=$([[ $VAL == 1 ]]  && echo special || echo ${WORDS1[$(($(shuf -i 1-${#WORDS1[@]} -n 1)-1))]})
WORDS2=("packages" "requests" "accounts" "deposits")
WORD2=$([[ $VAL == 1 ]]  && echo requests || echo ${WORDS2[$(($(shuf -i 1-${#WORDS2[@]} -n 1)-1))]})
cat > q13.sql <<DELIM
-- Customer Distribution Query (Q13)

SELECT c_count
	,count(*) AS custdist
FROM (
	SELECT c_custkey
		,count(o_orderkey) c_count
	FROM customer
	LEFT JOIN orders ON c_custkey = o_custkey
		AND o_comment NOT LIKE '%$WORD1%$WORD2%'
	GROUP BY c_custkey
	) AS c_orders
GROUP BY c_count
ORDER BY custdist DESC
	,c_count DESC;
DELIM