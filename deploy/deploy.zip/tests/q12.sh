#!/bin/bash
#Generate query 12 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
SHIPMODES1=("REG AIR" "AIR" "RAIL" "SHIP" "TRUCK" "MAIL" "FOB")
SHIPMODE1=$([[ $VAL == 1 ]]  && echo MAIL || echo ${SHIPMODES1[$(($(shuf -i 1-${#SHIPMODES1[@]} -n 1)-1))]})
SHIPMODES2=()
for S in ${SHIPMODES1[@]}; do if [ $S != $SHIPMODE1 ]; then SHIPMODES2+=($S); fi; done
SHIPMODE2=$([[ $VAL == 1 ]]  && echo SHIP || echo ${SHIPMODES2[$(($(shuf -i 1-${#SHIPMODES2[@]} -n 1)-1))]})
YEAR=$([[ $VAL == 1 ]]  && echo 1994 || echo $(shuf -i 1993-1997 -n 1))
cat > q12.sql <<DELIM
-- Shipping Modes and Order Priority Query (Q12)

SELECT l_shipmode
	,sum(CASE 
			WHEN o_orderpriority = '1-URGENT'
				OR o_orderpriority = '2-HIGH'
				THEN 1
			ELSE 0
			END) AS high_line_count
	,sum(CASE 
			WHEN o_orderpriority <> '1-URGENT'
				AND o_orderpriority <> '2-HIGH'
				THEN 1
			ELSE 0
			END) AS low_line_count
FROM orders
	,lineitem
WHERE o_orderkey = l_orderkey
	AND l_shipmode IN (
		'$SHIPMODE1'
		,'$SHIPMODE2'
		)
	AND l_commitdate < l_receiptdate
	AND l_shipdate < l_commitdate
	AND l_receiptdate >= DATE '$YEAR-01-01'
	AND l_receiptdate < ADD_DAYS(TO_DATE('$YEAR-01-01', 'YYYY-MM-DD'), + 360)
GROUP BY l_shipmode
ORDER BY l_shipmode;
DELIM