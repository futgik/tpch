#!/bin/bash
#Generate query 19 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
QUANTITY1=$([[ $VAL == 1 ]]  && echo 1 || echo $(shuf -i 1-10 -n 1))
QUANTITY2=$([[ $VAL == 1 ]]  && echo 10 || echo $(shuf -i 10-20 -n 1))
QUANTITY3=$([[ $VAL == 1 ]]  && echo 20 || echo $(shuf -i 20-30 -n 1))
M1=$([[ $VAL == 1 ]]  && echo 1 || echo $(shuf -i 1-5 -n 1))
N1=$([[ $VAL == 1 ]]  && echo 2 || echo $(shuf -i 1-5 -n 1))
M2=$([[ $VAL == 1 ]]  && echo 2 || echo $(shuf -i 1-5 -n 1))
N2=$([[ $VAL == 1 ]]  && echo 3 || echo $(shuf -i 1-5 -n 1))
M3=$([[ $VAL == 1 ]]  && echo 3 || echo $(shuf -i 1-5 -n 1))
N3=$([[ $VAL == 1 ]]  && echo 4 || echo $(shuf -i 1-5 -n 1))

cat > q19.sql <<DELIM
-- Discounted Revenue Query (Q19)

 SELECT sum(l_extendedprice * (1 - l_discount)) AS revenue
FROM lineitem
	,part
WHERE (
		p_partkey = l_partkey
		AND p_brand = 'Brand#$M1$N1'
		AND p_container IN (
			'SM CASE'
			,'SM BOX'
			,'SM PACK'
			,'SM PKG'
			)
		AND l_quantity >= $QUANTITY1
		AND l_quantity <= $QUANTITY1 + 10
		AND p_size BETWEEN 1
			AND 5
		AND l_shipmode IN (
			'AIR'
			,'AIR REG'
			)
		AND l_shipinstruct = 'DELIVER IN PERSON'
		)
	OR (
		p_partkey = l_partkey
		AND p_brand = 'Brand#$M2$N2'
		AND p_container IN (
			'MED BAG'
			,'MED BOX'
			,'MED PKG'
			,'MRD PACK'
			)
		AND l_quantity >= $QUANTITY2
		AND l_quantity <= $QUANTITY2 + 10
		AND p_size BETWEEN 1
			AND 10
		AND l_shipmode IN (
			'AIR'
			,'AIR REG'
			)
		AND l_shipinstruct = 'DELIVER IN PERSON'
		)
	OR (
		p_partkey = l_partkey
		AND p_brand = 'Brand#$M3$N3'
		AND p_container IN (
			'LG CASE'
			,'LG BOX'
			,'LG PACK'
			,'LG PKG'
			)
		AND l_quantity >= $QUANTITY3
		AND l_quantity <= $QUANTITY3 + 10
		AND p_size BETWEEN 1
			AND 15
		AND l_shipmode IN (
			'AIR'
			,'AIR REG'
			)
		AND l_shipinstruct = 'DELIVER IN PERSON'
		);
DELIM