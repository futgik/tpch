#!/bin/bash

SF=$1
ORDER_IC=$(($SF * 1500))
ORDER=orders.tbl.u1
LITEM=lineitem.tbl.u1

rm hana_insert.sql
touch hana_insert.sql

i=0
j=0
while read line
do
        echo $line
        LINEITEM_IC=$(shuf -i 1-7 -n 1)
        while read line
        do
                echo $line
				j=$(($j+1))
				break
        done < $LITEM
		j=0
		i=$(($i+1))
		break
done < $ORDER


        
        echo  $FILE1
        
        do
                FILE2=$line
                echo  $FILE2
        done < $2
done 
