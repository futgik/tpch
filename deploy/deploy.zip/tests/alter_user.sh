#!/bin/bash
#Alter user name if needed using using hdbsql

CP=$(hdbsql -u SYSTEM -p manager -i 00 -x -j -a "select PASSWORD_CHANGE_NEEDED from SYS.P_USER_PASSWORD_ as UP inner join "SYS"."P_USERS_" as PU on UP.OID = PU.OID and upper(PU.NAME)='TPCH'")

if [ $CP = 1 ];
then
        $(hdbsql -u $1 -p ${2:0:8} -i 00 -x -j -a "ALTER USER $1 PASSWORD $2")
fi
