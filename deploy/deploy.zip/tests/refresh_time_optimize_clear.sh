#!/bin/bash
#remove files after refresh_time_optimize_gen
INDEX=$1

rm rf1_$INDEX.sql
rm rf21_$INDEX.sql
rm rf22_$INDEX.sql