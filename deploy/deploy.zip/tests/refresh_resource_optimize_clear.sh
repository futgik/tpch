#!/bin/bash
#remove files after refresh_resource_optimize_gen
INDEX=$1

rm rf1_$INDEX.sql
rm rf2_$INDEX.sql