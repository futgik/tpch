#!/bin/bash
#Generate query 14 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
YEAR=$([[ $VAL == 1 ]]  && echo 1995 || echo $(shuf -i 1993-1997 -n 1))
MONTH=$([[ $VAL == 1 ]]  && echo 09 || (printf -v j "%02d" $(shuf -i 1-12 -n 1) && echo $j))
cat > q14.sql <<DELIM
-- Promotion Effect Query (Q14)

SELECT 100.00 * sum(CASE 
			WHEN p_type LIKE 'PROMO%'
				THEN l_extendedprice * (1 - l_discount)
			ELSE 0
			END) / sum(l_extendedprice * (1 - l_discount)) AS promo_revenue
FROM lineitem
	,part
WHERE l_partkey = p_partkey
	AND l_shipdate >= DATE '$YEAR-$MONTH-01'
	AND l_shipdate < ADD_DAYS(TO_DATE('$YEAR-$MONTH-01', 'YYYY-MM-DD'), + 30);
DELIM
