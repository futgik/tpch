#!/bin/bash
#Generate query 11 with random substitution parameters, when $1=1 and with validation values when $1=0.
#Second parameter represent scale factor
VAL=$1
SF=$2
NATIONS=("ALGERIA" "ARGENTINA" "BRAZIL" "CANADA" "EGYPT" "ETHIOPIA" "FRANCE" "GERMANY" "INDIA" "INDONESIA" "IRAN" "IRAQ" "JAPAN" "JORDAN" "KENYA" "MOROCCO" "MOZAMBIQUE" "PERU" "CHINA" "ROMANIA" "SAUDI ARABIA" "VIETNAM" "RUSSIA" "UNITED KINGDOM" "UNITED STATES")
NATION=$([[ $VAL == 1 ]]  && echo GERMANY || echo ${NATIONS[$(($(shuf -i 1-${#NATIONS[@]} -n 1)-1))]})
END_DIGIT=$([[ $SF == 3* ]] && echo 333333 || echo 1)
ZEROS_COUNT=$(( ${#SF} - $([[ $SF == 3* ]] && echo -1  || echo 0) ))
ZEROS=$(printf -v j "%0.s0" $(seq 1 $ZEROS_COUNT)   && echo $j)
FRACTION=$([[ $VAL == 1 ]]  && echo 0.0001 || echo $(echo 0.00$ZEROS$END_DIGIT))
cat > q11.sql <<DELIM
-- Important Stock Identification Query (Q11)

SELECT ps_partkey
	,sum(ps_supplycost * ps_availqty) AS value
FROM partsupp
	,supplier
	,nation
WHERE ps_suppkey = s_suppkey
	AND s_nationkey = n_nationkey
	AND n_name = '$NATION'
GROUP BY ps_partkey
HAVING sum(ps_supplycost * ps_availqty) > (
		SELECT sum(ps_supplycost * ps_availqty) * $FRACTION
		FROM partsupp
			,supplier
			,nation
		WHERE ps_suppkey = s_suppkey
			AND s_nationkey = n_nationkey
			AND n_name = '$NATION'
		)
ORDER BY value DESC;
DELIM
