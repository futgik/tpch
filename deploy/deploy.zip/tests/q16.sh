#!/bin/bash
#Generate query 16 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
M=$([[ $VAL == 1 ]]  && echo 4 || echo $(shuf -i 1-5 -n 1))
N=$([[ $VAL == 1 ]]  && echo 5 || echo $(shuf -i 1-5 -n 1))
SYLLABLE1=("STANDARD" "SMALL" "MEDIUM" "LARGE" "ECONOMY" "PROMO")
TYPE1=$([[ $VAL == 1 ]]  && echo MEDIUM || echo ${SYLLABLE1[$(($(shuf -i 1-${#SYLLABLE1[@]} -n 1)-1))]})
SYLLABLE2=("ANODIZED" "BURNISHED" "PLATED" "POLISHED" "BRUSHED")
TYPE2=$([[ $VAL == 1 ]]  && echo POLISHED || echo ${SYLLABLE2[$(($(shuf -i 1-${#SYLLABLE2[@]} -n 1)-1))]})
SIZE1=$([[ $VAL == 1 ]]  && echo 49 || echo $(shuf -i 1-50 -n 1))
SIZE2=$([[ $VAL == 1 ]]  && echo 14 || echo $(shuf -i 1-50 -n 1))
SIZE3=$([[ $VAL == 1 ]]  && echo 23 || echo $(shuf -i 1-50 -n 1))
SIZE4=$([[ $VAL == 1 ]]  && echo 45 || echo $(shuf -i 1-50 -n 1))
SIZE5=$([[ $VAL == 1 ]]  && echo 19 || echo $(shuf -i 1-50 -n 1))
SIZE6=$([[ $VAL == 1 ]]  && echo 3 || echo $(shuf -i 1-50 -n 1))
SIZE7=$([[ $VAL == 1 ]]  && echo 36 || echo $(shuf -i 1-50 -n 1))
SIZE8=$([[ $VAL == 1 ]]  && echo 9 || echo $(shuf -i 1-50 -n 1))
cat > q16.sql <<DELIM
-- Parts/Supplier Relationship Query (Q16)

SELECT p_brand
	,p_type
	,p_size
	,count(DISTINCT ps_suppkey) AS supplier_cnt
FROM partsupp
	,part
WHERE p_partkey = ps_partkey
	AND p_brand <> 'Brand#$M$N'
	AND p_type NOT LIKE '$TYPE1 $TYPE2%'
	AND p_size IN (
		$SIZE1
		,$SIZE2
		,$SIZE3
		,$SIZE4
		,$SIZE5
		,$SIZE6
		,$SIZE7
		,$SIZE8
		)
	AND ps_suppkey NOT IN (
		SELECT s_suppkey
		FROM supplier
		WHERE s_comment LIKE '%Customer%Complaints%'
		)
GROUP BY p_brand
	,p_type
	,p_size
ORDER BY supplier_cnt DESC
	,p_brand
	,p_type
	,p_size;
DELIM

