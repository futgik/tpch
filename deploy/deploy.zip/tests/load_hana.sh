#!/bin/bash
#The throughput test -> load_hana.sh <SF>, where SF is the current scale factor
#Parameters description:
#INSTANCES - Stream count.
#VALIDATION - Generate queries with random substitution parameters, when $1=1 and with validation values when $1=0.
#SF - scale factor.
#ORDERS_LINETEM_DIR - name of directory where data for generate refresh function be found.
#RF_INDEX - index for generating refresh functions.
#SCHEMA_NAME - name of tpch schema.
#HANA_USERNAME - hana user name.
#HANA_PASSWORD - hana password.

INSTANCES=$1
VALIDATION=$2
SF=$3
ORDERS_LINETEM_DIR=$4
RF_INDEX=$5
SCHEMA_NAME=$6
HANA_USERNAME=$7
HANA_PASSWORD=$8

if [ -z "$INSTANCES" ]
then
	echo $0 \<Num of instances\>
	exit
fi

echo Prepearing data for $INSTANCES instances
dos2unix streams_matrix.csv

#initialize temp file for refresh functions.
echo "-- refresh functions" > rf.sql

for(( i = 0; i < $INSTANCES; i++ ))
do
#refresh function generating
	echo create refresh function set $RF_INDEX
	sh ./refresh_gen.sh $ORDERS_LINETEM_DIR $RF_INDEX $SCHEMA_NAME $HANA_USERNAME $HANA_PASSWORD
	echo copy rf1_$RF_INDEX.sql into rf.sql
	cat rf1_$RF_INDEX.sql >> rf.sql	
	echo copy rf2_$RF_INDEX.sql into rf.sql
	cat rf2_$RF_INDEX.sql >> rf.sql
	echo "" >> rf.sql
	RF_INDEX=$(( $RF_INDEX + 1 ))

#parse file line containing query execution order.	
	line=$(head -n $((i+1)) streams_matrix.csv | tail -n 1)	
#	line=${line//,/ }
	line=$(echo "$line" | tr "," "\n")
	echo Instance $i using sequence \"$line\"
	echo "set schema "$SCHEMA_NAME";" > i_$i.sql
	
#prepare $i single query stream.
	for s in $line
	do
		echo generate query $s
		if [ $s == 11 ]
		then
			sh ./q$s.sh $VALIDATION $SF 
		elif [ $s == 15 ]
		then
			sh ./q$s.sh $VALIDATION $i
		else
			sh ./q$s.sh $VALIDATION
		fi
		echo copy q$s.sql into i_$i.sql
		cat q$s.sql >> i_$i.sql	
	done
	echo "" >> i_$i.sql
done

pids=()
tasks=()
max_concurrent_tasks=$(( $INSTANCES + 1 ))

#prepare execution tasks.
for(( i = 0; i < $INSTANCES; i++ ))
do
	tasks[$i]=$(echo hdbsql -u $HANA_USERNAME -p $HANA_PASSWORD -i 00 -x -j -a -f -o /dev/null -I i_$i.sql)
done
tasks[$INSTANCES]=$(echo hdbsql -u $HANA_USERNAME -p $HANA_PASSWORD -i 00 -x -j -a -f -o /dev/null -I rf.sql)

START=$(date +%s%N)
for key in "${!tasks[@]}";
do
	while [ $(jobs 2>&1 | grep -c Running) -ge "$max_concurrent_tasks" ];
	do
		sleep 1 # gnu sleep allows floating point here...
	done
	echo Running ${tasks[$key]}
	${tasks[$key]} &
	pids+=(["$key"]="$!")
done
errors=0
for key in "${!tasks[@]}"; do
	pid=${pids[$key]}
	cur_ret=0
	if [ -z "$pid" ]; then
		echo "No Job ID known for the $key process" # should never happen
		cur_ret=1
	else
		wait $pid
		cur_ret=$?
	fi
	if [ "$cur_ret" -ne 0 ]; then
		errors=$(($errors + 1))
		echo "$key (${tasks[$key]}) failed."
	fi
done
END=$(date +%s%N)
echo completed $INSTANCES streams and one refresh stream in $((($END-$START)/1000000)) ms
echo "$INSTANCES;$((($END-$START)/1000000))" > load_hana.log
rm i_*
rm rf.sql
