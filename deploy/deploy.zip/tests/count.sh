#!/bin/bash
#check an execution of a single query -> count.sh <query #>
#Parameters description:
#QUERY - executing query.
#VALIDATION - Generate query 1 with random substitution parameters, when $1=1 and with validation values when $1=0.
#SF - scale factor.
#HANA_USERNAME - hana user name.
#HANA_PASSWORD - hana password.
QUERY=$1
VALIDATION=$2
SF=$3
HANA_USERNAME=$4
HANA_PASSWORD=$5

echo "generate query $QUERY /n"
if [ $QUERY == q11 ]
then
	sh ./$QUERY.sh $VALIDATION $SF 
elif [ $QUERY == q15 ]
then
	sh ./$QUERY.sh $VALIDATION single
else
	sh ./$QUERY.sh $VALIDATION
fi
START=$(date +%s%N)
hdbsql -u $HANA_USERNAME -p $HANA_PASSWORD -i 00 -x -j -a -o output$QUERY -I $QUERY.sql
END=$(date +%s%N)
#echo ""
#cat $QUERY.sql
#echo ""
echo "Running $QUERY in $((($END-$START)/1000000)) ms"
echo "$QUERY;$((($END-$START)/1000000))" > count.log
rm $QUERY.sql