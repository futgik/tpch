#!/bin/bash
#generate 22 queries for power_test
#Parameters:
#VALIDATION - Generate query 1 with random substitution parameters, when $1=1 and with validation values when $1=0.
#SF - Scale factor.
VALIDATION=$1
SF=$2
echo "Generate query 1"
sh ./q1.sh $1
echo "Generate query 2"
sh ./q2.sh $1
echo "Generate query 3"
sh ./q3.sh $1
echo "Generate query 4"
sh ./q4.sh $1
echo "Generate query 5"
sh ./q5.sh $1
echo "Generate query 6"
sh ./q6.sh $1
echo "Generate query 7"
sh ./q7.sh $1
echo "Generate query 8"
sh ./q8.sh $1
echo "Generate query 9"
sh ./q9.sh $1
echo "Generate query 10"
sh ./q10.sh $1
echo "Generate query 11"
sh ./q11.sh $1 $2
echo "Generate query 12"
sh ./q12.sh $1
echo "Generate query 13"
sh ./q13.sh $1
echo "Generate query 14"
sh ./q14.sh $1
echo "Generate query 15"
sh ./q15.sh $1 0
echo "Generate query 16"
sh ./q16.sh $1
echo "Generate query 17"
sh ./q17.sh $1
echo "Generate query 18"
sh ./q18.sh $1
echo "Generate query 19"
sh ./q19.sh $1
echo "Generate query 20"
sh ./q20.sh $1
echo "Generate query 21"
sh ./q21.sh $1
echo "Generate query 22"
sh ./q22.sh $1