#!/bin/bash
#Generate query 3 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
SEGMENTS=("AUTOMOBILE" "BULDING" "FURNITURE" "MACHINERY" "HOUSEHOLD")
SEGMENT=$([[ $VAL == 1 ]]  && echo BULDING || echo ${SEGMENTS[$(($(shuf -i 1-${#SEGMENTS[@]} -n 1)-1))]})
DATE=$([[ $VAL == 1 ]]  && echo 15 || (printf -v j "%02d" $(shuf -i 1-31 -n 1) && echo $j))
cat > q3.sql <<DELIM
--Shipping Priority Query (Q3)

SELECT l_orderkey
	,sum(l_extendedprice * (1 - l_discount)) AS revenue
	,o_orderdate
	,o_shippriority
FROM customer
	,orders
	,lineitem
WHERE c_mktsegment = '$SEGMENT'
	AND c_custkey = o_custkey
	AND l_orderkey = o_orderkey
	AND o_orderdate < DATE '1995-03-$DATE'
	AND l_shipdate > DATE '1995-03-$DATE'
GROUP BY l_orderkey
	,o_orderdate
	,o_shippriority
ORDER BY revenue DESC
	,o_orderdate;
DELIM
