#!/bin/bash
#The refresh test
#Parameters:
#ORDERS_LINETEM_DIR - orders.tbl.u<INDEX> and lineitem.tbl.u<INDEX> path.
#INDEX - index of data for generating refresh functions.
#SCHEMA_NAME - name of tpch schema.
#HANA_USERNAME- hana user name; 
#HANA_PASSWORD - hana password; 

ORDERS_LINETEM_DIR=$1
INDEX=$2
SCHEMA_NAME=$3
HANA_USERNAME=$4
HANA_PASSWORD=$5

echo Prepare refresh functions.
sh ./refresh_time_optimize_gen.sh $ORDERS_LINETEM_DIR $INDEX $SCHEMA_NAME $HANA_USERNAME $HANA_PASSWORD

ALL_START=$(date +%s%N)

START=$(date +%s%N)
hdbsql -u $HANA_USERNAME -p $HANA_PASSWORD -i 00 -x -j -a -o outputrf1_$INDEX -I rf1_$INDEX.sql
END=$(date +%s%N)
echo rf1 completed in $((($END-$START)/1000000)) ms
echo "rf1;$((($END-$START)/1000000))" > refresh.log

sh ./rf2_test.sh refresh.log $INDEX $HANA_USERNAME $HANA_PASSWORD

ALL_END=$(date +%s%N)
echo The refresh functions completed in $((($ALL_END-$ALL_START)/1000000)) s
sh ./refresh_time_optimize_clear.sh $INDEX;