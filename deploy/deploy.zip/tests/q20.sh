#!/bin/bash
#Generate query 20 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
COLORS=("almond" "antique" "aquamarine" "azure" "beige" "bisque" "black" "blanched" "blue" "blush" "brown" "burlywood" "burnished" "chartreuse" "chiffon" "chocolate" "coral" "cornflower" "cornsilk" "cream" "cyan" "dark" "deep" "dim" "dodger" "drab" "firebrick" "floral" "forest" "frosted" "gainsboro" "ghost" "goldenrod" "green" "grey" "honeydew" "hot" "indian" "ivory" "khaki" "lace" "lavender" "lawn" "lemon" "light" "lime" "linen" "magenta" "maroon" "medium" "metallic" "midnight" "mint" "misty" "moccasin" "navajo" "navy" "olive" "orange" "orchid" "pale" "papaya" "peach" "peru" "pink" "plum" "powder" "puff" "purple" "red" "rose" "rosy" "royal" "saddle" "salmon" "sandy" "seashell" "sienna" "sky" "slate" "smoke" "snow" "spring" "steel" "tan" "thistle" "tomato" "turquoise" "violet" "wheat" "white" "yellow")
COLOR=$([[ $VAL == 1 ]]  && echo forest || echo ${COLORS[$(($(shuf -i 1-${#COLORS[@]} -n 1)-1))]})
YEAR=$([[ $VAL == 1 ]]  && echo 1994 || echo $(shuf -i 1993-1997 -n 1))
NATIONS=("ALGERIA" "ARGENTINA" "BRAZIL" "CANADA" "EGYPT" "ETHIOPIA" "FRANCE" "GERMANY" "INDIA" "INDONESIA" "IRAN" "IRAQ" "JAPAN" "JORDAN" "KENYA" "MOROCCO" "MOZAMBIQUE" "PERU" "CHINA" "ROMANIA" "SAUDI ARABIA" "VIETNAM" "RUSSIA" "UNITED KINGDOM" "UNITED STATES")
NATION=$([[ $VAL == 1 ]]  && echo CANADA || echo ${NATIONS[$(($(shuf -i 1-${#NATIONS[@]} -n 1)-1))]})
cat > q20.sql <<DELIM
-- Potential Part Promotion Query (Q20)

SELECT s_name, 
       s_address
FROM  supplier, 
       nation 
WHERE  s_suppkey IN (SELECT ps_suppkey 
                     FROM   partsupp 
                     WHERE  ps_partkey IN (SELECT p_partkey 
                                           FROM   part 
                                           WHERE  p_name LIKE '$COLOR%') 
                            AND ps_availqty > (SELECT 0.5 * Sum(l_quantity) 
												FROM   lineitem 
												WHERE l_partkey = ps_partkey 
													AND l_suppkey = ps_suppkey 
													AND l_shipdate >= DATE '$YEAR-01-01'
													AND l_shipdate < ADD_DAYS(TO_DATE('$YEAR-01-01', 'YYYY-MM-DD'), + 360)
												)) 
		AND s_nationkey = n_nationkey 
		AND n_name = '$NATION'
ORDER  BY s_name; 
DELIM