#!/bin/bash
#Generate query 18 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
QUANTITY=$([[ $VAL == 1 ]]  && echo 314 || echo $(shuf -i 312-315 -n 1))
cat > q18.sql <<DELIM
-- Large Volume Customer Query (Q18)

SELECT top 100
	   c_name, 
       c_custkey, 
       o_orderkey, 
       o_orderdate, 
       o_totalprice, 
       Sum(l_quantity) 
FROM   customer, 
       orders, 
       lineitem 
WHERE  o_orderkey IN (SELECT l_orderkey 
                      FROM   lineitem 
                      GROUP  BY l_orderkey 
                      HAVING Sum(l_quantity) > $QUANTITY) 
       AND c_custkey = o_custkey 
       AND o_orderkey = l_orderkey 
GROUP  BY c_name, 
          c_custkey, 
          o_orderkey, 
          o_orderdate, 
          o_totalprice 
ORDER  BY o_totalprice DESC, 
          o_orderdate; 
DELIM