#!/bin/bash
#Generate query 21 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
NATIONS=("ALGERIA" "ARGENTINA" "BRAZIL" "CANADA" "EGYPT" "ETHIOPIA" "FRANCE" "GERMANY" "INDIA" "INDONESIA" "IRAN" "IRAQ" "JAPAN" "JORDAN" "KENYA" "MOROCCO" "MOZAMBIQUE" "PERU" "CHINA" "ROMANIA" "SAUDI ARABIA" "VIETNAM" "RUSSIA" "UNITED KINGDOM" "UNITED STATES")
NATION=$([[ $VAL == 1 ]]  && echo "SAUDI ARABIA" || echo ${NATIONS[$(($(shuf -i 1-${#NATIONS[@]} -n 1)-1))]})
cat > q21.sql <<DELIM
-- Suppliers Who Kept Orders Waiting Query (Q21)

SELECT top 100
	s_name
	,count(*) AS numwait
FROM supplier
	,lineitem l1
	,orders
	,nation
WHERE s_suppkey = l1.l_suppkey
	AND o_orderkey = l1.l_orderkey
	AND o_orderstatus = 'F'
	AND l1.l_receiptdate > l1.l_commitdate
	AND EXISTS (
		SELECT *
		FROM lineitem l2
		WHERE l2.l_orderkey = l1.l_orderkey
			AND l2.l_suppkey <> l1.l_suppkey
		)
	AND NOT EXISTS (
		SELECT *
		FROM lineitem l3
		WHERE l3.l_orderkey = l1.l_orderkey
			AND l3.l_suppkey <> l1.l_suppkey
			AND l3.l_receiptdate > l3.l_commitdate
		)
	AND s_nationkey = n_nationkey
	AND n_name = '$NATION'
GROUP BY s_name
ORDER BY numwait DESC
	,s_name;
DELIM