#!/bin/bash
#Generate query 7 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
NATIONS1=("ALGERIA" "ARGENTINA" "BRAZIL" "CANADA" "EGYPT" "ETHIOPIA" "FRANCE" "GERMANY" "INDIA" "INDONESIA" "IRAN" "IRAQ" "JAPAN" "JORDAN" "KENYA" "MOROCCO" "MOZAMBIQUE" "PERU" "CHINA" "ROMANIA" "SAUDI ARABIA" "VIETNAM" "RUSSIA" "UNITED KINGDOM" "UNITED STATES")
NATION1=$([[ $VAL == 1 ]]  && echo FRANCE || echo ${NATIONS1[$(($(shuf -i 1-${#NATIONS1[@]} -n 1)-1))]})
NATIONS2=()
for ((i = 0; i < ${#NATIONS1[@]}; i++)); do if [ "${NATIONS1[$i]}" != "$NATION1" ]; then NATIONS2+=("${NATIONS1[$i]}"); fi; done

NATION2=$([[ $VAL == 1 ]]  && echo GERMANY || echo ${NATIONS2[$(($(shuf -i 1-${#NATIONS2[@]} -n 1)-1))]})
cat > q7.sql <<DELIM
-- Volume Shipping Query (Q7)

SELECT supp_nation
	,cust_nation
	,l_year
	,sum(volume) AS revenue
FROM (
	SELECT n1.n_name AS supp_nation
		,n2.n_name AS cust_nation
		,extract(year FROM l_shipdate) AS l_year
		,l_extendedprice * (1 - l_discount) AS volume
	FROM supplier
		,lineitem
		,orders
		,customer
		,nation n1
		,nation n2
	WHERE s_suppkey = l_suppkey
		AND o_orderkey = l_orderkey
		AND c_custkey = o_custkey
		AND s_nationkey = n1.n_nationkey
		AND c_nationkey = n2.n_nationkey
		AND (
			(
				n1.n_name = '$NATION1'
				AND n2.n_name = '$NATION2'
				)
			OR (
				n1.n_name = '$NATION2'
				AND n2.n_name = '$NATION1'
				)
			)
		AND l_shipdate BETWEEN DATE '1995-01-01'
			AND DATE '1996-12-31'
	) AS shipping
GROUP BY supp_nation
	,cust_nation
	,l_year
ORDER BY supp_nation
	,cust_nation
	,l_year;
DELIM