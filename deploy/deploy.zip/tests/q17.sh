#!/bin/bash
#Generate query 17 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
M=$([[ $VAL == 1 ]]  && echo 2 || echo $(shuf -i 1-5 -n 1))
N=$([[ $VAL == 1 ]]  && echo 3 || echo $(shuf -i 1-5 -n 1))
CONTAINERS1=("SM" "LG" "MED" "JUMBO" "WRAP")
TYPE1=$([[ $VAL == 1 ]]  && echo MED || echo ${CONTAINERS1[$(($(shuf -i 1-${#CONTAINERS1[@]} -n 1)-1))]})
CONTAINERS2=("CASE" "BOX" "BAG" "JAR" "PKG" "PACK" "CAN" "DRUM")
TYPE2=$([[ $VAL == 1 ]]  && echo BOX || echo ${CONTAINERS2[$(($(shuf -i 1-${#CONTAINERS2[@]} -n 1)-1))]})
cat > q17.sql <<DELIM
-- Small-Quantity-Order Revenue Query (Q17)

SELECT sum(l_extendedprice) / 7.0 AS avg_yearly
FROM lineitem
	,part
WHERE p_partkey = l_partkey
	AND p_brand = 'Brand#$M$N'
	AND p_container = '$TYPE1 $TYPE2'
	AND l_quantity < (
		SELECT 0.2 * avg(l_quantity)
		FROM lineitem
		WHERE l_partkey = p_partkey
		);
DELIM