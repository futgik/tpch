#!/bin/bash
#Generate query 1 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
DELTA=$([[ $VAL == 1 ]]  && echo 90 || echo $(shuf -i 60-120 -n 1))
cat > q1.sql <<DELIM
-- Pricing Summary Report Query (Q1)

SELECT l_returnflag,
       l_linestatus,
       Sum(l_quantity)                                           AS sum_qty,
       Sum(l_extendedprice)                                      AS
       sum_base_price,
       Sum(l_extendedprice * ( 1 - l_discount ))                 AS
       sum_disc_price,
       Sum(l_extendedprice * ( 1 - l_discount ) * ( 1 + l_tax )) AS sum_charge,
       Avg(l_quantity)                                           AS avg_qty,
       Avg(l_extendedprice)                                      AS avg_price,
       Avg(l_discount)                                           AS avg_disc,
       Count(*)                                                  AS count_order
FROM   lineitem
WHERE  l_shipdate <= Add_days (To_date ('1998-12-01', 'YYYY-MM-DD'), -$DELTA)
GROUP  BY l_returnflag,
          l_linestatus
ORDER  BY l_returnflag,
          l_linestatus;
DELIM