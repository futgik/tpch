#!/bin/bash
#generate sql refresh function1 scirpt.

ORDERS_LINETEM_DIR=$1
INDEX=$2

echo "--adds new sales information to the database
IMPORT FROM CSV FILE '$ORDERS_LINETEM_DIR/orders.tbl.u$INDEX' INTO orders WITH RECORD DELIMITED BY '\n' FIELD DELIMITED BY '|';
IMPORT FROM CSV FILE '$ORDERS_LINETEM_DIR/lineitem.tbl.u$INDEX' INTO lineitem WITH RECORD DELIMITED BY '\n' FIELD DELIMITED BY '|';" > rf1_$INDEX.sql