#!/bin/bash
#Generate query 5 with random substitution parameters, when $1=1 and with validation values when $1=0.
VAL=$1
REGIONS=("AFRICA" "AMERICA" "ASIA" "EUROPE" "MIDDLE EAST")
REGION=$([[ $VAL == 1 ]]  && echo ASIA || echo ${REGIONS[$(($(shuf -i 1-${#REGIONS[@]} -n 1)-1))]})
YEAR=$([[ $VAL == 1 ]]  && echo 1994 || echo $(shuf -i 1993-1997 -n 1))
cat > q5.sql <<DELIM
-- Local Supplier Volume Query (Q5)

SELECT n_name
	,sum(l_extendedprice * (1 - l_discount)) AS revenue
FROM customer
	,orders
	,lineitem
	,supplier
	,nation
	,region
WHERE c_custkey = o_custkey
	AND l_orderkey = o_orderkey
	AND l_suppkey = s_suppkey
	AND c_nationkey = s_nationkey
	AND s_nationkey = n_nationkey
	AND n_regionkey = r_regionkey
	AND r_name = '$REGION'
	AND o_orderdate >= DATE '$YEAR-01-01'
	AND o_orderdate < ADD_DAYS(TO_DATE('$YEAR-01-01', 'YYYY-MM-DD'), + 360)
GROUP BY n_name
ORDER BY revenue DESC;
DELIM