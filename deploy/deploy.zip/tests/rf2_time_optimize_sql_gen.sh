#!/bin/bash
#generate sql refresh function2 scirpt.

ORDERS_LINETEM_DIR=$1
INDEX=$2
SCHEMA_NAME=$3
HANA_USERNAME=$4
HANA_PASSWORD=$5

set -e

#Prepare sql tables DEL<INDEX> and import data into it.
CHECK_SCRIPT=$(echo "select COUNT(*) from PUBLIC.M_TABLES where SCHEMA_NAME='$SCHEMA_NAME' and TABLE_NAME='DEL$INDEX'")

CHECK_RES=$(hdbsql -u $HANA_USERNAME -p $HANA_PASSWORD -i 00 -x -j -a $CHECK_SCRIPT)


#DROP TABLE IF EXIST.
if [ $CHECK_RES -ge 1 ]
then	
	DROP_SCRIPT=$(echo "DROP TABLE DEL$INDEX CASCADE")
	echo Drop tabel DEL$INDEX
	hdbsql -u $HANA_USERNAME -p $HANA_PASSWORD -i 00 -x -j -a $DROP_SCRIPT
fi

CREATE_SCRIPT=$(echo "CREATE COLUMN TABLE DEL$INDEX (
	D_ORDERKEY	INTEGER
)")
IMPORT_SCRIPT=$(echo "IMPORT FROM CSV FILE '$ORDERS_LINETEM_DIR/delete.$INDEX' INTO DEL$INDEX WITH RECORD DELIMITED BY '\n' FIELD DELIMITED BY '|'")

echo Create table DEL$INDEX
hdbsql -u $HANA_USERNAME -p $HANA_PASSWORD -i 00 -x -j -a $CREATE_SCRIPT
echo Import data to table DEL$INDEX
hdbsql -u $HANA_USERNAME -p $HANA_PASSWORD -i 00 -x -j -a $IMPORT_SCRIPT

echo "--Remove old sales information from LINEITEM:
delete from LINEITEM
where LINEITEM.l_orderkey in (
       select d_orderkey from DEL$INDEX where DEL$INDEX.d_orderkey = LINEITEM.l_orderkey
);" > rf21_$INDEX.sql
echo "--Remove old sales information from ORDERS:
delete from ORDERS
where ORDERS.o_orderkey in (
       select d_orderkey from DEL$INDEX where DEL$INDEX.d_orderkey = ORDERS.o_orderkey
);" > rf22_$INDEX.sql