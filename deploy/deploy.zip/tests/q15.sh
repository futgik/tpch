#!/bin/bash
#Generate query 15 with random substitution parameters, when $1=1 and with validation values when $1=0.
#STREAM_ID using to generate query in throughput test.
VAL=$1
STREAM_ID=$2
YEAR=$([[ $VAL == 1 ]]  && echo 1996 || echo $(shuf -i 1993-1997 -n 1))
MONTH_MAX=$([[ $YEAR == 1997 ]] && echo 10 || echo 12)
MONTH=$([[ $VAL == 1 ]]  && echo 01 || (printf -v j "%02d" $(shuf -i 1-$MONTH_MAX -n 1) && echo $j))
cat > q15.sql <<DELIM
-- Top Supplier Query (Q15)

CREATE VIEW revenue_$STREAM_ID (
	supplier_no
	,total_revenue
	)
AS
SELECT l_suppkey
	,sum(l_extendedprice * (1 - l_discount))
FROM lineitem
WHERE l_shipdate >= DATE '$YEAR-$MONTH-01'
	AND l_shipdate < ADD_DAYS(TO_DATE('$YEAR-$MONTH-01', 'YYYY-MM-DD'), + 90)
GROUP BY l_suppkey;

SELECT s_suppkey
	,s_name
	,s_address
	,s_phone
	,total_revenue
FROM supplier
	,revenue_$STREAM_ID
WHERE s_suppkey = supplier_no
	AND total_revenue = (
		SELECT max(total_revenue)
		FROM revenue_$STREAM_ID
		)
ORDER BY s_suppkey;

DROP VIEW revenue_$STREAM_ID;
DELIM